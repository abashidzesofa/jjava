public class Main {
    public static void main(String[] args) {
        System.out.println("Проект 3:");
        System.out.println("Задание 1:");
        String str = "I study Basic Java!";
        System.out.println(str);
        System.out.println("Задание 2:");
        System.out.println(str.charAt(0));
        System.out.println("Задание 3:");
        System.out.println(str.charAt(str.length() - 1));
        System.out.println("Задание 4:");
        System.out.println(str.contains("Java"));
        System.out.println("Задание 5:");
        System.out.println("I study Basic Java!");
        System.out.println(str.replace('a', 'o'));
        System.out.println("Задание 6:");
        System.out.println(str.toUpperCase());
        System.out.println("Задание 7:");
        System.out.println(str.toLowerCase());
        System.out.println("Задание 8:");
        //System.out.println(str.length());
        System.out.println(str.substring(14, 18));


    }
}