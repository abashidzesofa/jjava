public class Main {
    public static void main(String[] args) {
        System.out.println("Проект 1: ");
        byte b = 1;
        short s = b;
        int i = s;
        long l = i;
        double d = l;
        System.out.println(b);
        System.out.println(s);
        System.out.println(i);
        System.out.println(l);
        System.out.println(d);




    }
}