public class Main {
    public static void main(String[] args) {
        System.out.println("Проект 2:");
        long lo = 1000L;
        byte b = (byte) lo;
        short s = (short) lo;
        int i = (int) lo;
        double d = (double) lo;
        System.out.println(lo);
        System.out.println(b);
        System.out.println(s);
        System.out.println(i);
        System.out.println(d);
    }
}